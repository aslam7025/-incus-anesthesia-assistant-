package com.example.status_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
